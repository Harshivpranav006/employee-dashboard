// Check authentication
function checkAuth() {
    const isAuthenticated = localStorage.getItem('isAuthenticated');
    if (!isAuthenticated) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

// Logout function
function logout() {
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('username');
    window.location.href = 'login.html';
}

// API Base URL
const API_URL = 'http://localhost:8080/api/employees';

// DOM Elements
const employeeForm = document.getElementById('employeeForm');
const employeeList = document.getElementById('employeeList');
const editModal = new bootstrap.Modal(document.getElementById('editModal'));
const editForm = document.getElementById('editForm');
const saveEditBtn = document.getElementById('saveEdit');
const searchInput = document.getElementById('searchInput');
const sortSelect = document.getElementById('sortSelect');
const filterDepartment = document.getElementById('filterDepartment');
const loadingSpinner = document.getElementById('loadingSpinner');
const notification = document.getElementById('notification');

// Form validation patterns
const validationPatterns = {
    phoneNumber: /^\d{10}$/,
    email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    salary: /^\d+(\.\d{1,2})?$/
};

// Show notification
function showNotification(message, type = 'success') {
    notification.textContent = message;
    notification.className = `alert alert-${type} notification`;
    notification.style.display = 'block';
    setTimeout(() => {
        notification.style.display = 'none';
    }, 3000);
}

// Show loading spinner
function showLoading() {
    loadingSpinner.style.display = 'block';
}

// Hide loading spinner
function hideLoading() {
    loadingSpinner.style.display = 'none';
}

// Validate form data
function validateFormData(data) {
    const errors = [];

    if (!data.firstName.trim()) errors.push('First name is required');
    if (!data.lastName.trim()) errors.push('Last name is required');
    if (!validationPatterns.email.test(data.email)) errors.push('Invalid email format');
    if (!validationPatterns.phoneNumber.test(data.phoneNumber)) errors.push('Phone number must be 10 digits');
    if (!data.department.trim()) errors.push('Department is required');
    if (!data.jobTitle.trim()) errors.push('Job title is required');
    if (!validationPatterns.salary.test(data.salary)) errors.push('Invalid salary format');

    return errors;
}

// Load employees when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadEmployees();
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Search functionality
    searchInput.addEventListener('input', debounce(loadEmployees, 300));

    // Sort functionality
    sortSelect.addEventListener('change', loadEmployees);

    // Filter functionality
    filterDepartment.addEventListener('change', loadEmployees);
}

// Debounce function for search
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Add Employee Form Submit
employeeForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const employee = {
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        email: document.getElementById('email').value,
        phoneNumber: document.getElementById('phoneNumber').value,
        department: document.getElementById('department').value,
        jobTitle: document.getElementById('jobTitle').value,
        salary: parseFloat(document.getElementById('salary').value)
    };

    const errors = validateFormData(employee);
    if (errors.length > 0) {
        showNotification(errors.join('\n'), 'danger');
        return;
    }

    try {
        showLoading();
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(employee)
        });

        if (response.ok) {
            employeeForm.reset();
            showNotification('Employee added successfully!');
            loadEmployees();
        } else {
            const error = await response.json();
            showNotification(error.message || 'Error adding employee', 'danger');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error adding employee', 'danger');
    } finally {
        hideLoading();
    }
});

// Load Employees
async function loadEmployees() {
    try {
        showLoading();
        const searchQuery = searchInput.value;
        const sortBy = sortSelect.value;
        const departmentFilter = filterDepartment.value;

        let url = API_URL;
        const params = new URLSearchParams();

        if (searchQuery) params.append('search', searchQuery);
        if (sortBy) params.append('sort', sortBy);
        if (departmentFilter) params.append('department', departmentFilter);

        if (params.toString()) {
            url += '?' + params.toString();
        }

        const response = await fetch(url);
        const employees = await response.json();

        employeeList.innerHTML = '';

        if (employees.length === 0) {
            employeeList.innerHTML = `
                <tr>
                    <td colspan="8" class="text-center">No employees found</td>
                </tr>
            `;
            return;
        }

        employees.forEach(employee => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${employee.id}</td>
                <td>${employee.firstName} ${employee.lastName}</td>
                <td>${employee.email}</td>
                <td>${employee.phoneNumber}</td>
                <td>${employee.department}</td>
                <td>${employee.jobTitle}</td>
                <td>₹${employee.salary.toFixed(2)}</td>
                <td>
                    <button class="btn btn-sm btn-primary me-2" onclick="editEmployee(${employee.id})">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteEmployee(${employee.id})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            employeeList.appendChild(row);
        });
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error loading employees', 'danger');
    } finally {
        hideLoading();
    }
}

// Edit Employee
async function editEmployee(id) {
    try {
        showLoading();
        const response = await fetch(`${API_URL}/${id}`);
        const employee = await response.json();

        document.getElementById('editId').value = employee.id;
        document.getElementById('editFirstName').value = employee.firstName;
        document.getElementById('editLastName').value = employee.lastName;
        document.getElementById('editEmail').value = employee.email;
        document.getElementById('editPhoneNumber').value = employee.phoneNumber;
        document.getElementById('editDepartment').value = employee.department;
        document.getElementById('editJobTitle').value = employee.jobTitle;
        document.getElementById('editSalary').value = employee.salary;

        editModal.show();
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error loading employee details', 'danger');
    } finally {
        hideLoading();
    }
}

// Save Edit
saveEditBtn.addEventListener('click', async () => {
    const id = document.getElementById('editId').value;
    const employee = {
        firstName: document.getElementById('editFirstName').value,
        lastName: document.getElementById('editLastName').value,
        email: document.getElementById('editEmail').value,
        phoneNumber: document.getElementById('editPhoneNumber').value,
        department: document.getElementById('editDepartment').value,
        jobTitle: document.getElementById('editJobTitle').value,
        salary: parseFloat(document.getElementById('editSalary').value)
    };

    const errors = validateFormData(employee);
    if (errors.length > 0) {
        showNotification(errors.join('\n'), 'danger');
        return;
    }

    try {
        showLoading();
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(employee)
        });

        if (response.ok) {
            editModal.hide();
            showNotification('Employee updated successfully!');
            loadEmployees();
        } else {
            const error = await response.json();
            showNotification(error.message || 'Error updating employee', 'danger');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error updating employee', 'danger');
    } finally {
        hideLoading();
    }
});

// Delete Employee
async function deleteEmployee(id) {
    if (confirm('Are you sure you want to delete this employee?')) {
        try {
            showLoading();
            const response = await fetch(`${API_URL}/${id}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                showNotification('Employee deleted successfully!');
                loadEmployees();
            } else {
                const error = await response.json();
                showNotification(error.message || 'Error deleting employee', 'danger');
            }
        } catch (error) {
            console.error('Error:', error);
            showNotification('Error deleting employee', 'danger');
        } finally {
            hideLoading();
        }
    }
} 